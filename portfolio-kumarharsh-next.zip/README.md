# Kumar Harsh – Portfolio (Next.js)

This is my personal portfolio built using **Next.js**, **Framer Motion**, and **Tailwind CSS** (or minimal styling).

## 🚀 To Run Locally

```bash
npm install
npm run dev
```

## 📦 Deploy on Vercel

1. Push this folder to GitHub.
2. Go to [vercel.com](https://vercel.com), import your repo.
3. Done!
